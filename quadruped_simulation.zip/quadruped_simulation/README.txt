-------------------------------------------------------------------------------
Compilation -> Type Swift_make('qpSWIFT_mex') in your matlab command window
            -> Add the mex file to your working directory to use qpSWIFT
-------------------------------------------------------------------------------
Usage       -> Instructions on how to use the mex-file are given in qpSWIFT.m
                                    or
            -> Type help qpSWIFT in your matlab command window
-------------------------------------------------------------------------------
Demo        -> Demo QP is given in demoqp.m
-------------------------------------------------------------------------------


-------------------------------------------------------------------------------
Note: Make sure you have compatible C compiler available for your matlab version
-------------------------------------------------------------------------------
